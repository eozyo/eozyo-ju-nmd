window.onload = function() { 

	var start_button = document.getElementById("start");
	start_button.onclick = function () { StartGame(); }
	

}

function StartGame() {
	var position;
	var quit_confirm;
	var game_over	= false;
	var tools		= ["none","uniform","teaser","ID Card"];

	var breaker = 0;
	
	position = prompt(_return_msg("instructions"));
	
	while(game_over==false) {
		
		if(position!=null) {
			alert("it's not null");
		
		
		
		

		
		
		} else {
			quit_confirm = confirm("Are you sure you want to quit?");
			if(quit_confirm==true) {
				game_over = true;
				console.log("Player canceled the game.");
				alert("You'canceled the game. Game Over.")
				break;
			} else {
				position = prompt(_return_msg("instructions"));
			}
		}
		
		
		breaker++;
		if(breaker > 5) { game_over = true; alert("auto-stop"); }
	}
	
	
	
	
	

	alert(position);
}


function _return_msg($msg) {
	var msg;
	switch($msg) {
		case "instructions": 
			msg = "The elevator doors open up, and as soon as you step out they close\nand let you trapped in a small lobby.\nThe lobby has, besides the elevator's, 3 other doors. The only way out\nis through out the elevator you entered.\n\nWhat would you like to do?\n\nPress (1) to open the door to the left.\nPress (2) to open the door in front of you.\nPress (3) to open the door to the right.\nPress (4) to input code in the elevator keypad.";
		break;	
		default:
			msg = "default";
	}
	
	return msg;
}

function _return_room($quadrant,$boss,$tool) {
	var room = {
		quadrant: $quadrant,
		boss: $boss,
		tool: $tool
	}
	return room;
}





function _random($min,$max) {
	var r = ($min<0) ? $min + Math.random()*(Math.abs($min)+$max) : $min + Math.random()*$max;
	return Math.round(r);
}